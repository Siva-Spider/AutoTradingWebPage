import React from "react";

export default function ProfileCard() {
  return (
    <div className="text-sm bg-gray-100 p-2 rounded">
      <p>User ID: --</p>
      <p>Name: --</p>
      <p>Email: --</p>
      <p>Total Balance: --</p>
      <p>Margin Used: --</p>
      <p>Available Balance: --</p>
    </div>
  );
}
